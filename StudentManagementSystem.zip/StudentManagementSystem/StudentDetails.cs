﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagementSystem
{
 
    class StudentDetails
    {
        static int num, ind = 0;
        static void StudentReports(List<StudentManagement> hs)
        {


            foreach (StudentManagement s in hs)
            {
                Console.WriteLine("Marks");
                Console.WriteLine("----------");
                for (int i = 0; i < s.marks.Length; i++)
                {
                    Console.WriteLine(s.subjects[i] + "\t" + " = " + s.marks[i] + "\t\t");
                }
                Console.WriteLine("StudID\t\tName\t\tStudy\t    Total\t    Percentage");
                Console.WriteLine("_______\t     _________\t      _______\t    _________\t  __________\t ");

                Console.WriteLine(" " + s.studId + "\t\t" + s.studName + "\t\t  " + s.Class + "\t\t" + s.total + "\t\t" + s.avg);
            }      
        }

        static void display(List<StudentManagement> hs)
        {
            Console.WriteLine("StudID\t\tName\t\tStudy\t    Total\t    Percentage");
            Console.WriteLine("_______\t     _________\t      _______\t    _________\t  __________\t ");
            foreach (StudentManagement s in hs)
            {
                
   Console.WriteLine(" " + s.studId + "\t\t" + s.studName + "\t\t  " + s.Class + "\t\t" + s.total + "\t\t" + s.avg);
                
            }
        }
        static void Remove(List<StudentManagement> hs)
        {
            Console.WriteLine("Enter the Student id to delete the record");
            int id = int.Parse(Console.ReadLine());
            foreach (StudentManagement s in hs)
            {
                if (id == s.studId)
                {
                    hs.Remove(s);
                    num--;
                    return;
                }
            }
        }
       


        static void insertRecords()
        {

            float total, avg;
            float[] marks;
            string[] subjects;
            Console.WriteLine("Enter Student Id name class");
            int id = int.Parse(Console.ReadLine());
            string name = Console.ReadLine();
            int stud = int.Parse(Console.ReadLine());
            Console.WriteLine("ENTER no of subjects");
            int n = int.Parse(Console.ReadLine());
            marks = new float[n];
            subjects = new string[n];
            total = 0f;
            for (int i = 0; i < subjects.Length; i++)
            {
                Console.WriteLine("Enter the subject Name");
                subjects[i] = Console.ReadLine();
                Console.Write("Enter the Subject:{0} marks  = ", i + 1);
                marks[i] = float.Parse(Console.ReadLine());
                total = total + marks[i];
            }
            avg = total / n;
            StudentManagement s = new StudentManagement(id, name,stud,subjects,marks, total, avg);
            num++;
            hash.Add(s);
        }
        
        
        static List<StudentManagement> hash;
        static void Main(string[] args)
        {
            bool flag = true;
            hash = new List<StudentManagement>();
            Console.WriteLine("1) INSERT STUDENT DETAILS");
            Console.WriteLine("2) REMOVE STUDENT RECORD");
            Console.WriteLine("3) DISPLAY STUDENT RECORDS");
            Console.WriteLine("4) STUDENT RECORDS");
            Console.WriteLine("5) EXIT");

            while (true)
            {
                Console.WriteLine("Enter your choice");
                int ch = int.Parse(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        insertRecords();
                        Console.WriteLine("Inserted");
                        break;
                    case 2:
                        Remove(hash);
                        Console.WriteLine("Deleted");
                        break;
                    case 3:
                        display(hash);
                        break;
                    case 4: StudentReports(hash);break;
                    case 5:
                         Environment.Exit(1);
                        break;
                }
            }
            Console.ReadLine();
        }
    }
}

